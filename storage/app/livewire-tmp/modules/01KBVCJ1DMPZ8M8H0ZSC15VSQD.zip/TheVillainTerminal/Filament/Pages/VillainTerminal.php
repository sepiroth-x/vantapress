<?php

namespace Modules\TheVillainTerminal\Filament\Pages;

use Filament\Pages\Page;
use Filament\Notifications\Notification;
use Modules\TheVillainTerminal\Services\TerminalExecutor;
use Illuminate\Support\Facades\Log;

/**
 * The Villain Terminal - Filament Page
 * 
 * Web-based terminal interface for VantaPress.
 */
class VillainTerminal extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-command-line';

    protected static string $view = 'thevillainterrminal::terminal';

    protected static ?string $navigationLabel = 'Villain Terminal';

    protected static ?string $title = 'The Villain Terminal';

    protected static ?string $navigationGroup = 'System';

    protected static ?int $navigationSort = 100;

    public string $username = '';
    public string $prompt = '';

    /**
     * Mount the terminal page
     */
    public function mount(): void
    {
        // Set username for prompt
        $user = auth()->user();
        
        if ($user && $user->name) {
            $this->username = strtolower(str_replace(' ', '', $user->name));
        } elseif ($user && $user->email) {
            $this->username = strtolower(explode('@', $user->email)[0]);
        } else {
            $this->username = 'villain';
        }

        $this->prompt = "{$this->username}@villain-terminal:~$ ";

        Log::info('[Villain Terminal] Terminal accessed', [
            'user_id' => auth()->id(),
            'username' => $this->username
        ]);
    }

    /**
     * Execute a terminal command (called from frontend)
     * 
     * @param string $command
     * @return array
     */
    public function executeCommand(string $command): array
    {
        Log::info('[Villain Terminal] Command received', [
            'command' => $command,
            'user_id' => auth()->id()
        ]);

        // Special commands that don't need registry
        if ($command === 'clear') {
            return [
                'success' => true,
                'clear' => true,
                'output' => ''
            ];
        }

        if ($command === 'help' || $command === 'vanta-help') {
            $command = 'vanta-help';
        }

        // Execute through the terminal executor
        $executor = new TerminalExecutor();
        $result = $executor->execute($command);

        return $result;
    }

    /**
     * Get available commands for autocomplete
     * 
     * @return array
     */
    public function getAvailableCommands(): array
    {
        return \Modules\TheVillainTerminal\Services\CommandRegistry::getCommandNames();
    }

    /**
     * Check if user can access terminal
     * 
     * @return bool
     */
    public static function canAccess(): bool
    {
        $user = auth()->user();
        
        // Only super admins can access
        if (!$user) {
            return false;
        }

        // Check if user has super_admin role or is user ID 1
        return $user->id === 1 || $user->hasRole('super_admin');
    }

    /**
     * Get header actions
     */
    protected function getHeaderActions(): array
    {
        return [];
    }
}
